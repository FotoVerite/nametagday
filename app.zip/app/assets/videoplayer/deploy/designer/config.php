<?php
$config = array(
    'ispreview' => 'off',
    'csslocation' => '../../videogallery/skin_custom.css',
    'xmllocation' => '../xml/design.xml',
    'swflocation' => '../preview.swf',
    'user' => 'admin',
    'password' => 'thepassword',
    );