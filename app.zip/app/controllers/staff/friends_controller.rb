class Staff::FriendsController < ApplicationController
end
